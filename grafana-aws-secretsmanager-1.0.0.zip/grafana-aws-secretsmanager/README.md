A Grafana backend plugin that stores datasource secrets in AWS Secrets Manager. Secrets normally are stored in AWS Secrets Manager in addition to Grafana's default SQL database for the sake of backwards compatibility, but you can configure Grafana to disable use of the SQL database.

## Requirements

### Supported operating systems

- MacOS (Darwin AMD64 and ARM64)
- Linux (AMD64, ARM, and ARM64)
- Windows (AMD64)

### Dependencies

This plugin is packaged in a single native executable with the AWS Go SDK bundled. This means you don’t need any additional dependencies outside of those required to run Grafana.

Using AWS services programmatically requires valid credentials, so you will be required to set up a user with programmatic access via [Amazon’s IAM service](https://aws.amazon.com/iam/). You can also use [Amazon’s KMS service](https://aws.amazon.com/kms/) to create an encryption key for your secrets. The plugin can be configured manually through Grafana's configuration, but it is also possible to do so via environment variables setup with the [AWS CLI](https://aws.amazon.com/cli/). 

Information on how to configure the AWS Secrets Manager plugin can be found in the [Grafana Enterprise documentation](https://grafana.com/docs/grafana/latest/enterprise/).

## Plugin installation

You can install the plugin using Grafana CLI:

```bash
grafana-cli plugins install grafana-aws-secrets-manager
```

After the plugin is installed, it must be explicitly enabled. See [Configuration and troubleshooting](#configuration-and-troubleshooting).

## Configuration and troubleshooting
 
For available configuration settings and troubleshooting help, please refer to [Grafana AWS Secrets Manager documentation](https://grafana.com/docs/grafana/latest/enterprise/).
